﻿using System.ComponentModel.DataAnnotations;

namespace MVC_Assignment5.Models
{
    public class DateofBirthValidator : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            DateTime dt = Convert.ToDateTime(value);
            if (dt != null)
            {
                if (dt >= Convert.ToDateTime("1/1/2002") && dt <= DateTime.Parse("12/12/2005"))
                {
                    return ValidationResult.Success;
                }
            }

            return new ValidationResult(ErrorMessage ?? "DOB should be in Range");
        }
    }
}
