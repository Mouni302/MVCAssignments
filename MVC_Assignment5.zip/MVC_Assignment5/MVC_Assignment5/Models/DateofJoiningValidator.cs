﻿using System.ComponentModel.DataAnnotations;

namespace MVC_Assignment5.Models
{
    public class DateofJoiningValidator : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            DateTime dt = Convert.ToDateTime(value);
            if (dt != null)
            {
                if (dt <= DateTime.Today)
                {
                    return ValidationResult.Success;
                }
            }

            return new ValidationResult(ErrorMessage ?? "DOJ shub in Range");
        }
    }
}
