﻿using System.ComponentModel.DataAnnotations;

namespace MVC_Assignment5.Models
{
    public class DepartmentValidator : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            string dept = (string) value;
            if (dept == "HR" || dept == "Accounts" || dept == "IT")
            {
                return ValidationResult.Success;
            }

            return new ValidationResult(ErrorMessage ?? "Department is not valid");
        }
    }
}
