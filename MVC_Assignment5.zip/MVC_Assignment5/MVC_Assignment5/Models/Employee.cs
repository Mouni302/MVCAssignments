﻿using System.ComponentModel.DataAnnotations;

namespace MVC_Assignment5.Models
{
    public class Employee
    {
        [Required(ErrorMessage = "Id is must")]
        public int Id { get; set; }

        [Required(ErrorMessage = "First Name is must")]
        [RegularExpression(@"[A-Za-z ]+", ErrorMessage = "Only alphabets are allowed")]
        [StringLength(30, ErrorMessage = "30 characters are allowed")]
        [MinLength(15, ErrorMessage = "Min 15 characaters needed")]
        public string Name { get; set; }

        [Required(ErrorMessage = "DOB is must")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DateofBirthValidator]
        public DateTime DOB { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DateofJoiningValidator]
        public DateTime DateOfJoining { get; set; }

        [Required]
        [SalaryValidator]
        public int Salary { get; set; }

        [Required]
        [DepartmentValidator]
        public string Dept {  get; set; }

        [Required]
        [DataType(DataType.Password)]
        [RegularExpression(@"^[A-Z][a-zA-Z0-9]+")]
        public string Password {  get; set; }
    }
}
