﻿using System.ComponentModel.DataAnnotations;

namespace MVC_Assignment5.Models
{
    public class SalaryValidator : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            int salary = (int) value;
            if (salary<=60000 && salary>=12000 )
            {
                return ValidationResult.Success;
            }
           
            return new ValidationResult(ErrorMessage ?? "Salary Should be in Range");
        }
    }
}
