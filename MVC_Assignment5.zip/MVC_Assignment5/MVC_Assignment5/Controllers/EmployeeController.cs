﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVC_Assignment5.Models;

namespace MVC_Assignment5.Controllers
{
    public class EmployeeController : Controller
    {
        static List<Employee> employees = null;

        public EmployeeController()
        {
            if (employees == null)
            {
                employees = new List<Employee>()
                {

                };
            }
        }
        public ActionResult Index()
        {
            if (employees.Count == 0)
            {
                ViewBag.msg = "No Employees are added";
            }

            return View(employees.ToList());
        }

        // GET: EmployeeController/Details/5
        public ActionResult Details(int? id)
        {
            Employee employee = null;
            if (!id.HasValue)
            {
                ViewBag.msg = "Please provide valid id";
            }
            else
            {
                employee = employees.Where(x => x.Id == id).FirstOrDefault();
                if (employee == null)
                {
                    ViewBag.msg = "Employee ID is not Exist";
                }
            }
            return View(employee);
        }

        // GET: EmployeeController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EmployeeController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee employee)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    employees.Add(employee);

                    return RedirectToAction(nameof(Index));
                }
                else
                    return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeController/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                ViewBag.msg = "Please provide a valid ID";

            }
            var employee = employees.Where(x => x.Id == id).FirstOrDefault();
            if (employee == null)
                ViewBag.msg = "employee with ID do not exist";

            return View(employee);
        }

        // POST: EmployeeController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Employee employee)
        {
            try
            {
                foreach (var item in employees)
                {
                    if (item.Id == id)
                    {
                        item.Password = employee.Password;
                        item.Dept = employee.Dept;
                        item.DateOfJoining = employee.DateOfJoining;
                        item.DOB = employee.DOB;
                        item.Salary = employee.Salary;
                        item.Name = employee.Name;
                        item.Id = employee.Id;
                        break;
                    }

                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeController/Delete/5
        public ActionResult Delete(int id)
        {
            if (id == null)
            {
                ViewBag.msg = "Please provide a valid ID";

            }
            var employee = employees.Where(x => x.Id == id).FirstOrDefault();
            if (employee == null)
                ViewBag.msg = "Employee with ID do not exist";
            return View(employee);
        }

        // POST: EmployeeController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Employee employee)
        {
            try
            {
                var user = employees.Where(x => x.Id == id).FirstOrDefault();
                employees.Remove(user);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
