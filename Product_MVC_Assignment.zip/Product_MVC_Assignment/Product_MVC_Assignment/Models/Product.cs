﻿namespace Product_MVC_Assignment.Models
{
    public class Product
    {
        public int PCode { get; set; }
        public string PName { get; set; }
        public int QtyInStock { get; set; }
        public string Details { get; set; }
        public int Price { get; set; }

    }
}
