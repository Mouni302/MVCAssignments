﻿using Microsoft.AspNetCore.Mvc;
using Product_MVC_Assignment.Models;

namespace Product_MVC_Assignment.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult Display()
        {
            Product product = new Product()
            {
                PCode = 101,
                PName = "Tshirt",
                QtyInStock = 10,
                Details = "Cotton",
                Price = 300
            };

            ViewBag.Product = product;
            return View();
        }

        public IActionResult GetAllProducts()
        {
            List<Product> products = new List<Product>()
            {
                new Product() {PCode = 101, PName = "Tshirt", QtyInStock = 10, Details = "Cotton", Price = 300},
                new Product() {PCode = 102, PName = "Shirt", QtyInStock = 30, Details = "Cotton", Price = 500},
                new Product() {PCode = 103, PName = "Dress", QtyInStock = 60, Details = "rayon", Price = 700},
                new Product() {PCode = 104, PName = "Saree", QtyInStock = 100, Details = "georgette", Price = 100},
                new Product() {PCode = 105, PName = "Pants", QtyInStock = 50, Details = "polyster", Price = 800},
            };

            ViewBag.Products = products;

            return View();

        }

        public IActionResult DisplayProduct()
        {
            Product product = new Product()
            {
                PCode = 101,
                PName = "Tshirt",
                QtyInStock = 10,
                Details = "Cotton",
                Price = 300
            };
            return View(product);
        }

        public IActionResult GetProducts()
        {
            List<Product> products = new List<Product>()
            {
                new Product() {PCode = 101, PName = "Tshirt", QtyInStock = 10, Details = "Cotton", Price = 300},
                new Product() {PCode = 102, PName = "Shirt", QtyInStock = 30, Details = "Cotton", Price = 500},
                new Product() {PCode = 103, PName = "Dress", QtyInStock = 60, Details = "rayon", Price = 700},
                new Product() {PCode = 104, PName = "Saree", QtyInStock = 100, Details = "georgette", Price = 100},
                new Product() {PCode = 105, PName = "Pants", QtyInStock = 50, Details = "polyster", Price = 800},
            };

            return View(products);

        }
    }
}
