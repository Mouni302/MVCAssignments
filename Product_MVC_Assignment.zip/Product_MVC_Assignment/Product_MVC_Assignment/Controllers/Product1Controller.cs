﻿using Microsoft.AspNetCore.Mvc;
using Product_MVC_Assignment.Models;

namespace Product_MVC_Assignment.Controllers
{
    public class Product1Controller : Controller
    {
        static List<Product> products = null;

        public Product1Controller()
        {
            if (products == null)
            {
                products = new List<Product>()
                {
                    new Product() {PCode = 101, PName = "Tshirt", QtyInStock = 10, Details = "AAAA", Price = 300},
                    new Product() {PCode = 102, PName = "Shirt", QtyInStock = 30, Details = "BBBB", Price = 500},
                    new Product() {PCode = 103, PName = "MAc", QtyInStock = 60, Details = "CCCC", Price = 700},
                    new Product() {PCode = 104, PName = "Mobile", QtyInStock = 100, Details = "DDDD", Price = 100},
                    new Product() {PCode = 105, PName = "Laptop", QtyInStock = 50, Details = "EEEEE", Price = 800},
                };
            }
        }
        public IActionResult Index()
        {
            return View(products.ToList());
        }

        public IActionResult Details(int id)
        {
            var product = products.Where(x => x.PCode == id).FirstOrDefault();
            return View(product);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Product product)
        {
            products.Add(product);
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            var product = products.Where(x => x.PCode == id).FirstOrDefault();
            return View(product);
        }
        [HttpPost]
        public IActionResult Edit(int id, Product product)
        {
            foreach (var p in products)
            {
                if (p.PCode == id)
                {
                    p.Details = product.Details;
                    p.QtyInStock = product.QtyInStock;
                    p.Price = product.Price;
                    break;
                }
                
            }
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var product = products.Where(x => x.PCode == id).FirstOrDefault();
            return View(product);
        }
        [HttpPost]
        public IActionResult Deleted(int id)
        {
            //var product = products.Where(x => x.PCode == id).FirstOrDefault();

            
            foreach(var p in products)
            {
                if(p.PCode == id)
                {
                    products.Remove(p);
                    break;
                }
            }
            return RedirectToAction("Index");
        }
    }
}
